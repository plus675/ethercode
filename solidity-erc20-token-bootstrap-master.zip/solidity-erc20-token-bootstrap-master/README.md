# solidity-erc20-token-bootstrap
You are able to publish it using official Ethereum client.

Russian tutorial is available at [vc.ru](https://vc.ru/28314-sozdaem-svoy-erc20-token-na-baze-ethereum-za-2-minuty).
